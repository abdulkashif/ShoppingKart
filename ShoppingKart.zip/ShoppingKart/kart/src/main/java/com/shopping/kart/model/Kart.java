package com.shopping.kart.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "USER_KART")
public class Kart {
    @Column(name = "ID")
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
  
    @Column(name = "USER_NAME", nullable = true, length = 255)
    private String uname;
    private Integer prodId;
  
    @Column(nullable = true, length = 255)
    private String prodName;
    private Integer qty;
    private Double price;

    
  
    public Kart(Integer id, String uname, String prodName, Integer qty, Double price) {
		super();
		this.id = id;
		this.uname = uname;
		this.prodName = prodName;
		this.qty = qty;
		this.price = price;
	}



	public Kart() {
    }



	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}



	public String getUname() {
		return uname;
	}



	public void setUname(String uname) {
		this.uname = uname;
	}



	public String getProdName() {
		return prodName;
	}



	public void setProdName(String prodName) {
		this.prodName = prodName;
	}



	public Integer getQty() {
		return qty;
	}



	public void setQty(Integer qty) {
		this.qty = qty;
	}



	public Double getPrice() {
		return price;
	}



	public void setPrice(Double price) {
		this.price = price;
	}



	public Integer getProdId() {
		return prodId;
	}



	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}


}