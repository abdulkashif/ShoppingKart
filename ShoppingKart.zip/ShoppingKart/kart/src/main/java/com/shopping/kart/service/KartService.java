package com.shopping.kart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shopping.kart.dao.KartDao;
import com.shopping.kart.model.Kart;

@Service
 public class KartService {
     @Autowired
     KartDao kartDao;
 
     public List<Kart> getAllKart(String uname) {
         return this.kartDao.findByUname(uname);
    	 //return this.kartDao.findAll();
     }
 
     public Kart addItem(Kart user) {
    	 Kart kart = this.kartDao.findByProdId(user.getProdId());
    	 if(kart==null)
         return this.kartDao.save(user);
    	 else {
    		 kart.setQty(kart.getQty()+1);
    		 return this.kartDao.save(kart);
    	 }
     }

	public void deleteById(int kartId) {
		// TODO Auto-generated method stub
		this.kartDao.deleteById(kartId);
		
	}

	public Kart findById(int id) {
		// TODO Auto-generated method stub
		return this.kartDao.findById(id).get();
	}

	public void update(Kart kart) {
		// TODO Auto-generated method stub
		System.out.println(this.kartDao.save(kart));
	}

	public void deleteByUname(String uname) {
		// TODO Auto-generated method stub
		int f = this.kartDao.deleteByUname(uname);
		System.out.println("Deleted from kart "+f);
	}
 
 }