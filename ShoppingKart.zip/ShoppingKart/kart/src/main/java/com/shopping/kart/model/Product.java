package com.shopping.kart.model;

public class Product {
	private Integer id;
	private String name;
	private String description;
	private Integer qty;
	private double price;
	
	
	
	public Product(Integer id, String name, String description, Integer qty, double price) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.qty = qty;
		this.price = price;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getQty() {
		return qty;
	}
	public void setQty(Integer qty) {
		this.qty = qty;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
