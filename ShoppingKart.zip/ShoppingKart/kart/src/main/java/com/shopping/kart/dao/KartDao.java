package com.shopping.kart.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shopping.kart.model.Kart;


@Repository
public interface KartDao extends JpaRepository<Kart, Integer> {
	List<Kart> findByUname(String uname);
	Kart findByProdId(Integer id);
	//long deleteByUname(String uname);
	@Modifying
	@Query("delete from Kart k where k.uname=:uname")
	@Transactional
	int deleteByUname(@Param("uname") String uname);
}