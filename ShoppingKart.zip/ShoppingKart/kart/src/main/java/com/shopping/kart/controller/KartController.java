package com.shopping.kart.controller;

import javax.management.relation.RelationNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.shopping.kart.model.Kart;
import com.shopping.kart.model.KartListClass;
import com.shopping.kart.service.KartService;

@RestController
 public class KartController {
     @Autowired
     KartService kartService;
 
     @RequestMapping(value = "/all/{uname}", method = RequestMethod.GET)
     public KartListClass getAllKart(@PathVariable String uname) {
    	 System.out.println("in kart srvice getall"+uname);
    	 KartListClass retKart = new KartListClass(kartService.getAllKart(uname));
		 return retKart;
     }
 
     @RequestMapping(value = "/additem", method = RequestMethod.POST,
             consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
     @ResponseBody()
     public KartListClass addNewItem(@RequestBody Kart item) {
    	 		System.out.println("in kart service"+item.getProdName());
    		 this.kartService.addItem(item);
    		 KartListClass retKart = new KartListClass(kartService.getAllKart(item.getUname()));
    		 return retKart;
    
         
     }
     @RequestMapping(path="/delete/{kartId}",method=RequestMethod.DELETE)
     public ResponseEntity<Void> deleteById(@PathVariable int kartId) {
      kartService.deleteById(kartId);
      return ResponseEntity.noContent().build();
     }
     
     @RequestMapping(path="/deleteKart/{uname}",method=RequestMethod.DELETE)
     public ResponseEntity<Void> deleteById(@PathVariable String uname) {
      kartService.deleteByUname(uname);
      return ResponseEntity.noContent().build();
     }
     
     @RequestMapping(path="/findById/{id}",method=RequestMethod.GET)
     public ResponseEntity<Kart> findById(@PathVariable int id) {
    	 try {
    		  // 
    		  Kart kart = kartService.findById(id);
    		  return ResponseEntity.ok(kart);  // return 200, with json body
    		 } catch (Exception e) {
    		  return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); //return 404, with null body
    		 }
     }
     @RequestMapping(path="/update/{id}",method=RequestMethod.PUT)
     public ResponseEntity<Void> updateKart(@PathVariable int id, @RequestBody Kart kart) {
    	 try {
    		  
    		 System.out.println(kart.getId());
    		 
    		 kartService.update(kart);
    		  return ResponseEntity.noContent().build();
    		 } catch (Exception e) {
    		  return ResponseEntity.notFound().build();
    		 }
     }
 
 }