It has 3 spring boot applications.
MainAppApplication is the main application which calls KartApplication and ProductListApplication microservices.