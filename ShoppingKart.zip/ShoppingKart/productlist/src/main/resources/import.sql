INSERT INTO product_details VALUES(1,'Stuff to do','Laptop',130.5,40);
INSERT INTO product_details VALUES(2,'Use this now','Product',45.30,40);
INSERT INTO product_details VALUES(3,'Another description','Another product',11,64);
INSERT INTO product_details VALUES(4,'Call people','Phone',110.2,55);
INSERT INTO product_details VALUES(5,'Stuff ..','Book',10.5,15);
INSERT INTO product_details VALUES(6,'Some description','Another Product',45.30,80);
INSERT INTO product_details VALUES(7,'Nice!!','Useful product',11,7);
INSERT INTO product_details VALUES(8,'Learn something maybe','Tutorial',25,20);
