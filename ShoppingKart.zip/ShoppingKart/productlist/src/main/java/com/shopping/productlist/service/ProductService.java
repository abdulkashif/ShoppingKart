package com.shopping.productlist.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shopping.productlist.dao.ProductDao;
import com.shopping.productlist.model.AllProduct;
import com.shopping.productlist.model.Kart;
import com.shopping.productlist.model.Product;

@Service
 public class ProductService {
     @Autowired
     ProductDao prodDao;
 
     public AllProduct getAllProds() {
    	 System.out.println(prodDao.findAll());
    	 List<Product> productList = this.prodDao.findAll();
    	 AllProduct allProduct = new AllProduct();
    	 allProduct.setProductList(productList);
         return allProduct;
     }
     
     public Product getProdById(Integer id) {
    	 return prodDao.findById(id).get();
     }
     
     public String addProd() {
//    	 System.out.println("In the addProd+++++++++++++++");
   	 Product product = new Product();
  	 product.setDescription("desc");
       product.setName("sample");
       product.setPrice(12.0);
       product.setQty(5);
//        System.out.println("In the ddd+++++++++++++++");
    this.prodDao.save(product);
//         System.out.println("%%%%%%%%%%5+++++++++++++++");
  return "Product";
     }

	public void updateProds(List<Kart> item) {
		// TODO Auto-generated method stub
		item.stream().forEach(x->{
			Product prod = prodDao.findById(x.getProdId()).get();
			prod.setQty(prod.getQty()-x.getQty());
			prodDao.save(prod);
		});
	}
}