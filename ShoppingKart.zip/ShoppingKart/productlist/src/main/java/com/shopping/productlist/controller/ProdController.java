package com.shopping.productlist.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.shopping.productlist.model.AllProduct;
import com.shopping.productlist.model.Kart;
import com.shopping.productlist.model.Product;
import com.shopping.productlist.service.ProductService;

@RestController
 @RequestMapping("/product")
 public class ProdController {
     @Autowired
     ProductService prodService;
 
     @RequestMapping(method = RequestMethod.GET,value = "/all")
     public AllProduct getAllProds() {
         return (AllProduct) prodService.getAllProds();
     }
     
     @RequestMapping(value = "/update", method = RequestMethod.POST,
             consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
     @ResponseBody()
     public ResponseEntity<Void> addNewItem(@RequestBody List<Kart> item) {
    	 prodService.updateProds(item);
    	 return ResponseEntity.noContent().build();
         
     }
     
     
     @RequestMapping(value = "/{id}", method = RequestMethod.GET)
     public Product getAllKart(@PathVariable Integer id) {
    	 System.out.println(id);
         return prodService.getProdById(id);
     }
}