package com.shopping.productlist.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


@Entity
@Table(name = "PRODUCT_DETAILS")
public class Product {
    @Column(name = "PROD_ID")
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
  
    @Column(name = "PROD_NAME", nullable = true, length = 255)
    private String name;
  
    @Column(nullable = true, length = 255)
    private String description;
    
    @Column(nullable = true, length = 10)
    private Integer qty;
    
    @Column(nullable = true, length = 10)
    private Double price;

  
    public Product() {
    }

    
    
	public Integer getId() {
		return id;
	}


	public Product(Integer id, String name, String description, Integer qty, Double price) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.qty = qty;
		this.price = price;
	}

	public void setId(Integer id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}



	public Integer getQty() {
		return qty;
	}


	public void setQty(Integer qty) {
		this.qty = qty;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public Double getPrice() {
		return price;
	}


	public void setPrice(Double price) {
		this.price = price;
	}


    

}