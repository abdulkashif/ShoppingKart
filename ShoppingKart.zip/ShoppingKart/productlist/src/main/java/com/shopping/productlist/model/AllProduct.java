package com.shopping.productlist.model;
import java.util.List;



public class AllProduct {
	
	public List<Product> productList;
   
	
    public AllProduct(List<Product> list) {
    	this.productList=list;
    }

    public AllProduct() {
    	
    }

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}
    
    
    
    
}
