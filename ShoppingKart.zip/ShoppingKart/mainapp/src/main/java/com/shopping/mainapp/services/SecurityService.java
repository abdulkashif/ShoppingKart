package com.shopping.mainapp.services;
public interface SecurityService {
    String findLoggedInUsername();

    void autoLogin(String username, String password);
}