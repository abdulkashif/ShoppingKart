package com.shopping.mainapp.services;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


import com.shopping.mainapp.dao.OrderRepository;
import com.shopping.mainapp.model.Kart;
import com.shopping.mainapp.model.KartListClass;
import com.shopping.mainapp.model.Order;
@Service
public class OrderService {
	
	@Autowired
    OrderRepository orderDao;

	public List<Order> retrieveOrders(String uname) {
		
		return orderDao.findByUname(uname);
		
	}

	public Order getOrderDetails(int id) {
		// TODO Auto-generated method stub
		return orderDao.findById(id).get();
	}

	

    
}
