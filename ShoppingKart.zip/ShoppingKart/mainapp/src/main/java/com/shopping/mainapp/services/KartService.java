package com.shopping.mainapp.services;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


import com.shopping.mainapp.dao.OrderRepository;
import com.shopping.mainapp.model.AllProduct;
import com.shopping.mainapp.model.Kart;
import com.shopping.mainapp.model.KartListClass;
import com.shopping.mainapp.model.Order;
@Service
public class KartService {
	
	@Autowired
    OrderRepository orderDao;

	public List<Kart> getKart(String uname) {
		String findUrl = "http://localhost:8060/all/"+uname;
		//System.out.println(uname);
		RestTemplate rest = new RestTemplate();
		KartListClass prod = rest.getForObject(findUrl, KartListClass.class);
		//System.out.println("@@@@@@"+prod);
		return prod.getKartList();
	}

	public void deleteProd(Integer id) {
		// TODO Auto-generated method stub
		RestTemplate rest = new RestTemplate();
		String entityUrl = "http://localhost:8060/delete/" + id;
		rest.delete(entityUrl);
		
	}

	public Kart findById(int id) {
		String findUrl = "http://localhost:8060/findById/"+id;
		System.out.println(id);
		RestTemplate rest = new RestTemplate();
		Kart kart = rest.getForObject(findUrl, Kart.class);
		//System.out.println("@@@@@@"+prod);
		return kart;
	}

	public void updateKart(Kart kart) {
		String updateURL = "http://localhost:8060/update/"+kart.getId();
		 System.out.println(kart.getProdId());
	    RestTemplate restTemplate = new RestTemplate();
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
//	    JSONObject personJsonObject = new JSONObject();
//	   
//		personJsonObject.put("item", kart);
		HttpEntity <Kart> httpEntity = new HttpEntity <Kart> (kart, headers);
		restTemplate.exchange(updateURL,HttpMethod.PUT, httpEntity, Void.class);
	}

	public Integer placeOrder(Order order, String uname) {
		String findUrl = "http://localhost:8060/all/"+uname;
		
		RestTemplate rest = new RestTemplate();
		KartListClass prod = rest.getForObject(findUrl, KartListClass.class);
		
		order.setProdList(prod.getKartList());
		order.setUname(uname);
		//save order
		Order ord = orderDao.save(order);
		//delete from kart
		String entityUrl = "http://localhost:8060/deleteKart/" + order.getUname();
		rest.delete(entityUrl);
		//update the quantity
		String updateQty = "http://localhost:8053/product/update";
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity <List<Kart>> httpEntity = new HttpEntity <List<Kart>> (prod.getKartList(), headers);
		rest.postForObject(updateQty, httpEntity, Void.class);
		
		
		System.out.println("in final service"+ord.getProdList().toString());
		return ord.getOrder_id();
	}
    
}
