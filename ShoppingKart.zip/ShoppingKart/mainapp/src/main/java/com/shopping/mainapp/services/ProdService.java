package com.shopping.mainapp.services;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.shopping.mainapp.model.AllProduct;
import com.shopping.mainapp.model.Kart;
import com.shopping.mainapp.model.KartListClass;
import com.shopping.mainapp.model.Product;


	@Service
	public class ProdService {

	    public List<Product> retrieveProds() {
	    	RestTemplate restTemplate = new RestTemplate();
	    	AllProduct response = restTemplate.getForObject("http://localhost:8053/product/all", AllProduct.class);
	    	//System.out.println("3333333333333"+response);
	    	
	    	//System.out.println("*********************"+response.getProdList());
	        return response.getProdList();
	    }

		public List<Kart> addToCart(Kart kart) {
			String addToCartURL = "http://localhost:8060/additem";
		    RestTemplate restTemplate = new RestTemplate();
		    HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity <Kart> httpEntity = new HttpEntity <Kart> (kart, headers);
			KartListClass response = restTemplate.postForObject(addToCartURL, httpEntity, KartListClass.class);
			
			return response.getKartList();
			
		}

		public Product findById(Integer id) {
			String findUrl = "http://localhost:8053/product/"+id;
			RestTemplate rest = new RestTemplate();
			Product prod = rest.getForObject(findUrl, Product.class);
			System.out.println("@@@@@@"+prod.getName());
			return prod;
		}
		
	

	}

