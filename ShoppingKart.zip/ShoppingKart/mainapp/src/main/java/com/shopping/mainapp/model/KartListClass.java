package com.shopping.mainapp.model;

import java.util.List;

public class KartListClass {
	List<Kart> kartList;

	public KartListClass(){
		
	}
	public KartListClass(List<Kart> kartList) {
		super();
		this.kartList = kartList;
	}

	public List<Kart> getKartList() {
		return kartList;
	}

	public void setKartList(List<Kart> kartList) {
		this.kartList = kartList;
	}
	

}
