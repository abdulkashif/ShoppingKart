package com.shopping.mainapp.model;

import javax.persistence.Embeddable;

@Embeddable
public class Kart {
	private Integer id;
	private String uname;
	private Integer prodId;
	private String prodName;
	private Integer qty;
	private Double price;

	public Kart() {
		
	}
	
	
	public Kart(Integer id,String uname, Integer prodId, String prodName, Integer qty, Double price) {
		
		this.uname = uname;
		this.prodId = prodId;
		this.prodName = prodName;
		this.qty = qty;
		this.price = price;
	}


	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public Integer getQty() {
		return qty;
	}
	public void setQty(Integer qty) {
		this.qty = qty;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Integer getProdId() {
		return prodId;
	}
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}

	

}
