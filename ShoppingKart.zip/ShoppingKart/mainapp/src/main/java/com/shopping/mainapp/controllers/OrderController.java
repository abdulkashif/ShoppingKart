package com.shopping.mainapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.shopping.mainapp.model.Kart;
import com.shopping.mainapp.model.Order;
import com.shopping.mainapp.services.OrderService;

@Controller
@SessionAttributes("name")
public class OrderController {
	

	@Autowired
	OrderService orderService;
	
	@RequestMapping(value="/my-orders", method = RequestMethod.GET)
	public String showOrders(ModelMap model){
		String uname = (String) model.get("name");
		model.put("orders", orderService.retrieveOrders(uname));
		return "/my-orders";
	}
	@RequestMapping(value = "/order-detail", method = RequestMethod.GET)
	public String oderDetails(ModelMap model, @RequestParam int id) {
		Order or =orderService.getOrderDetails(id);
		System.out.println(id+"order-details...."+or.getOrder_id());
		System.out.println(or.getProdList());
		List<Kart> k = (List<Kart>) or.getProdList();
		System.out.println("........."+k.get(0).getProdName());
		model.put("ord",(List<Kart>)or.getProdList());

		return "/order-detail";
	}
}
