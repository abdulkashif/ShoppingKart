package com.shopping.mainapp.controllers;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.shopping.mainapp.model.Kart;
import com.shopping.mainapp.model.Order;
import com.shopping.mainapp.services.KartService;

@Controller
@SessionAttributes("name")
public class KartController {

	@Autowired
	KartService kartService;

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		// Date - dd/MM/yyyy
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(
				dateFormat, false));
	}

	@RequestMapping(value="/kart", method = RequestMethod.GET)
	public String showKart(ModelMap model){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName();
		System.out.println("In Kart Controller ----"+(String)model.get("name"));
		model.put("items", kartService.getKart(currentPrincipalName));
		return "kart";
	}
	
	@RequestMapping(value = "/delete-prod", method = RequestMethod.GET)
	public String deleteFromCart(@RequestParam Integer id, ModelMap model) {
		kartService.deleteProd(id);
		
		return "redirect:/kart";
		
	}
	
	@RequestMapping(value = "/update-prod", method = RequestMethod.GET)
	public String showUpdatePage(@RequestParam int id, ModelMap model) {
		Kart kart = kartService.findById(id);
		model.put("kart", kart);
		return "editKart";
	}
	@RequestMapping(value = "/update-prod", method = RequestMethod.POST)
	public String updateQty(ModelMap model, Kart kart,
			BindingResult result) {

		if (result.hasErrors()) {
			return "editKart";
		}
		
		
		
		Kart kart2 = kartService.findById(kart.getId());
		kart2.setQty(kart.getQty());
		//kart2.setPrice(kart2.getPrice()*kart.getQty());

		kartService.updateKart(kart2);

		return "redirect:/kart";
	}
	@RequestMapping(value = "/billing-details", method = RequestMethod.GET)
	public String getBilling() {
		
		return "/billing-details";
		
	}
	@RequestMapping(value = "/billing-details", method = RequestMethod.POST)
	public String finalSave(ModelMap model, Order order,
			BindingResult result) {

		if (result.hasErrors()) {
			return "editKart";
		}
		
		order.setOrderDate(new Date());
		System.out.println("final -----------"+order.getAdr());
		System.out.println("final -----------"+order.getExpiry());
		System.out.println("Lassstttt----"+(String)model.get("name"));
		String uname =(String)model.get("name");
		Integer id = kartService.placeOrder(order,uname);
//		Kart kart2 = kartService.findById(kart.getId());
//		kart2.setQty(kart.getQty());
//		//kart2.setPrice(kart2.getPrice()*kart.getQty());
//
//		kartService.updateKart(kart2);
		model.put("id",id);
		return "/success";
	}
	
}
