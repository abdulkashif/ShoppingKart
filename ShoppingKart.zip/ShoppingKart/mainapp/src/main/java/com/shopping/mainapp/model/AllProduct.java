package com.shopping.mainapp.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AllProduct {
	@JsonProperty("productList")
	public List<Product> prodList;
	
	public AllProduct() {
		prodList = new ArrayList<>();
		
	}

	public AllProduct(List<Product> prodList) {

		this.prodList = prodList;
	}

	public List<Product> getProdList() {
		return prodList;
	}

	public void setProdList(List<Product> prodList) {
		this.prodList = prodList;
	}
	
	

}
