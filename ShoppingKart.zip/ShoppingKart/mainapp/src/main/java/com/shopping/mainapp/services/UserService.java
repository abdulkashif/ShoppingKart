package com.shopping.mainapp.services;

import com.shopping.mainapp.model.User;

public interface UserService {
    void save(User user);

    User findByUsername(String username);
}