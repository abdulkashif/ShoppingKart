package com.shopping.mainapp.model;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="ORDER_TABLE")
public class Order {
	
	@Column(name = "ORDER_ID")
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer order_id;
	private String fname;
	private String uname;
	private String email;
	private String adr;
	private Date orderDate;
	private String cname;
	private Long ccnum;
	private String expiry;

	@ElementCollection
	private Collection<Kart> prodList;
	
	public Order(){
		
	}
	
	
	



	

	public Order(Integer order_id, String fname, String uname, String email, String adr, Date orderDate, String cname,
			Long ccnum, String expiry, Collection<Kart> prodList) {
		super();
		this.order_id = order_id;
		this.fname = fname;
		this.uname = uname;
		this.email = email;
		this.adr = adr;
		this.orderDate = orderDate;
		this.cname = cname;
		this.ccnum = ccnum;
		this.expiry = expiry;
		this.prodList = prodList;
	}








	public Integer getOrder_id() {
		return order_id;
	}








	public void setOrder_id(Integer order_id) {
		this.order_id = order_id;
	}








	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAdr() {
		return adr;
	}
	public void setAdr(String adr) {
		this.adr = adr;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public Long getCcnum() {
		return ccnum;
	}
	public void setCcnum(Long ccnum) {
		this.ccnum = ccnum;
	}
	public String getExpiry() {
		return expiry;
	}
	public void setExpiry(String expiry) {
		this.expiry = expiry;
	}
	public Collection<Kart> getProdList() {
		return prodList;
	}
	public void setProdList(Collection<Kart> prodList) {
		this.prodList = prodList;
	}


	public String getUname() {
		return uname;
	}


	public void setUname(String uname) {
		this.uname = uname;
	}


	public Date getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	
}
