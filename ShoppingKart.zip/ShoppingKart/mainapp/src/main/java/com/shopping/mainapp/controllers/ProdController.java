package com.shopping.mainapp.controllers;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.shopping.mainapp.model.Kart;
import com.shopping.mainapp.model.Product;
import com.shopping.mainapp.services.ProdService;

@Controller
@SessionAttributes("name")
public class ProdController {

	@Autowired
	ProdService prodService;

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		// Date - dd/MM/yyyy
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(
				dateFormat, false));
	}

	@RequestMapping(value = "/add-prod", method = RequestMethod.GET)
	public String addToCart(@RequestParam Integer id, ModelMap model) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName();
		model.put("name", currentPrincipalName);
		System.out.println("**************"+ currentPrincipalName);
		System.out.println((String)model.get("name"));
		Product prod = prodService.findById(id);
		Kart kart = new Kart();
		kart.setUname(currentPrincipalName);
		kart.setProdId(prod.getId());
		kart.setProdName(prod.getName());
		kart.setQty(1);
		kart.setPrice(prod.getPrice());
		model.put("items", prodService.addToCart(kart));
		return "kart";
	}

	
}
